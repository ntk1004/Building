package com.example.Project2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Project2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
