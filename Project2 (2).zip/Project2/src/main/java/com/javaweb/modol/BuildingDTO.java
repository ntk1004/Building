package com.javaweb.modol;

public class BuildingDTO{
private String name;
private String dia_chi;
private Integer numberofbasement;
private String managername;
private String managerphonenumber;
private Integer floorarea;
private Integer area_trong;
private Integer rentprice;
private Integer servicefee;
private double brokeragefee;
private String area;
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getDia_chi() {
	return dia_chi;
}
public void setDia_chi(String dia_chi) {
	this.dia_chi = dia_chi;
}
public Integer getNumberofbasement() {
	return numberofbasement;
}
public void setNumberofbasement(Integer numberofbasement) {
	this.numberofbasement = numberofbasement;
}
public String getManagername() {
	return managername;
}
public void setManagername(String managername) {
	this.managername = managername;
}
public String getManagerphonenumber() {
	return managerphonenumber;
}
public void setManagerphonenumber(String managerphonenumber) {
	this.managerphonenumber = managerphonenumber;
}
public Integer getFloorarea() {
	return floorarea;
}
public void setFloorarea(Integer floorarea) {
	this.floorarea = floorarea;
}
public Integer getArea_trong() {
	return area_trong;
}
public void setArea_trong(Integer area_trong) {
	this.area_trong = area_trong;
}
public Integer getRentprice() {
	return rentprice;
}
public void setRentprice(Integer rentprice) {
	this.rentprice = rentprice;
}
public Integer getServicefee() {
	return servicefee;
}
public void setServicefee(Integer servicefee) {
	this.servicefee = servicefee;
}
public double getBrokeragefee() {
	return brokeragefee;
}
public void setBrokeragefee(double brokeragefee) {
	this.brokeragefee = brokeragefee;
}
public String getArea() {
	return area;
}
public void setArea(String area) {
	this.area = area;
}
}
