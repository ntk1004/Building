//package com.javaweb.repository.custom.impl;
//
//
//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.ResultSet;
//import java.sql.Statement;
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Map;
//import java.util.Set;
//
//import org.springframework.stereotype.Repository;
//
//import com.javaweb.repository.rentAreaRepository;
//import com.javaweb.repository.entity.rentArea;
//@Repository
//public class rentAreaRepositoryimpl implements rentAreaRepository {
//
//private final String DB_URL= "jdbc:mysql://localhost:3306/estatebasic" ;
//private final String USER = "root";
//private final String PASS = "30102004";
//@Override
//public List<rentArea> Area(Integer id) {
//		
//	return null;
//	}
//}
