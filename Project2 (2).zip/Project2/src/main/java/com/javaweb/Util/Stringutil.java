package com.javaweb.Util;

public class Stringutil {
public static boolean checkString(String s) {
	if (s!= null && !s.equals("")) return true;
	else	return false;
	
}
}
